# Credit Card Default Prediction Service

A production-ready ML web service for predicting credit card default using the
[UCI Default of Credit Card Clients dataset](https://www.kaggle.com/datasets/uciml/default-of-credit-card-clients-dataset).
Built with Flask, scikit-learn, Docker, and A/B testing support.

---

## Table of Contents

1. [Project Overview](#project-overview)
2. [Repository Structure](#repository-structure)
3. [Quick Start (Local)](#quick-start-local)
4. [Docker Deployment](#docker-deployment)
5. [API Reference](#api-reference)
6. [A/B Testing](#ab-testing)
7. [Architecture](#architecture)
8. [Docker Hub](#docker-hub)

---

## Project Overview

**Domain:** Financial / Credit Scoring  
**Goal:** Predict whether a client will default on their credit card payment
next month (`1 = default`, `0 = no default`).

| Model | Algorithm | Notes |
|-------|-----------|-------|
| v1 | LogisticRegression | Baseline — interpretable, fast |
| v2 | GradientBoostingClassifier | Improved non-linear capture |

---

## Repository Structure

```
credit-card-ml-deployment/
├── app/
│   ├── __init__.py
│   ├── api.py              # Flask application (endpoints)
│   └── model_handler.py   # Model loading and inference
├── models/
│   ├── train_model.py      # Training script
│   ├── model_v1.pkl        # Saved model v1
│   ├── model_v2.pkl        # Saved model v2
│   └── metadata.json       # Model metrics
├── tests/
│   └── test_api.py         # pytest test suite (10 tests)
├── docker/
│   ├── Dockerfile
│   └── nginx.conf
├── docs/
│   └── ARCHITECTURE.md     # Architecture decisions
├── data/                   # Place UCI_Credit_Card.csv here
├── ab_test_plan.md         # A/B test plan
├── docker-compose.yml
├── requirements.txt
└── README.md
```

---

## Quick Start (Local)

### 1. Clone and set up environment

```bash
git clone https://github.com/YOUR_USERNAME/credit-card-ml-deployment.git
cd credit-card-ml-deployment

python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. (Optional) Add real dataset

Download [UCI_Credit_Card.csv](https://www.kaggle.com/datasets/uciml/default-of-credit-card-clients-dataset)
and place it at `data/UCI_Credit_Card.csv`. Without it, synthetic data is used automatically.

### 3. Train the models

```bash
python models/train_model.py
```

### 4. Start the service

```bash
python app/api.py
# Service running at http://localhost:5000
```

### 5. Run tests

```bash
pytest tests/test_api.py -v
```

---

## Docker Deployment

### Build and run

```bash
# Build image
docker build -f docker/Dockerfile -t credit-card-default-predictor .

# Run container
docker run -p 5000:5000 credit-card-default-predictor
```

### Docker Compose (with NGINX + log monitor)

```bash
docker-compose up --build
# Service available at http://localhost (via NGINX port 80)
# Direct access:       http://localhost:5000
```

### Pull from Docker Hub

```bash
docker pull YOUR_DOCKERHUB_USERNAME/credit-card-default-predictor:latest
docker run -p 5000:5000 YOUR_DOCKERHUB_USERNAME/credit-card-default-predictor:latest
```

---

## API Reference

### `GET /health`

Health check for Docker and load balancers.

```bash
curl http://localhost:5000/health
```

```json
{
  "status": "healthy",
  "service": "credit-card-default-predictor",
  "timestamp": "2024-11-15T09:23:11Z"
}
```

---

### `POST /predict`

Predict default for a single client.

**Query parameters:**

| Parameter | Values | Default | Description |
|-----------|--------|---------|-------------|
| `version` | `v1`, `v2`, `ab` | `ab` | Model version. `ab` = random 50/50 routing |

**Request body:**

```json
{
  "LIMIT_BAL":  50000,
  "SEX":        2,
  "EDUCATION":  2,
  "MARRIAGE":   1,
  "AGE":        35,
  "PAY_0":      0,
  "PAY_2":      0,
  "PAY_3":      0,
  "PAY_4":      0,
  "PAY_5":      0,
  "PAY_6":      0,
  "BILL_AMT1":  15000,
  "BILL_AMT2":  14000,
  "BILL_AMT3":  13000,
  "BILL_AMT4":  12000,
  "BILL_AMT5":  11000,
  "BILL_AMT6":  10000,
  "PAY_AMT1":   1500,
  "PAY_AMT2":   1400,
  "PAY_AMT3":   1300,
  "PAY_AMT4":   1200,
  "PAY_AMT5":   1100,
  "PAY_AMT6":   1000
}
```

**Response:**

```json
{
  "prediction":    0,
  "probability":   0.2786,
  "model_version": "v1",
  "risk_label":    "LOW"
}
```

**curl examples:**

```bash
# Model v1 (explicit)
curl -X POST "http://localhost:5000/predict?version=v1" \
  -H "Content-Type: application/json" \
  -d '{"LIMIT_BAL":50000,"SEX":2,"EDUCATION":2,"MARRIAGE":1,"AGE":35,
       "PAY_0":0,"PAY_2":0,"PAY_3":0,"PAY_4":0,"PAY_5":0,"PAY_6":0,
       "BILL_AMT1":15000,"BILL_AMT2":14000,"BILL_AMT3":13000,
       "BILL_AMT4":12000,"BILL_AMT5":11000,"BILL_AMT6":10000,
       "PAY_AMT1":1500,"PAY_AMT2":1400,"PAY_AMT3":1300,
       "PAY_AMT4":1200,"PAY_AMT5":1100,"PAY_AMT6":1000}'

# Model v2 (explicit)
curl -X POST "http://localhost:5000/predict?version=v2" \
  -H "Content-Type: application/json" \
  -d '{"LIMIT_BAL":50000,"AGE":35,"PAY_0":2,"BILL_AMT1":40000}'

# A/B routing (50% chance v1, 50% chance v2)
curl -X POST "http://localhost:5000/predict" \
  -H "Content-Type: application/json" \
  -d '{"LIMIT_BAL":50000,"AGE":35}'
```

---

### `GET /models`

List available models and their training metrics.

```bash
curl http://localhost:5000/models
```

```json
{
  "available_versions": ["v1", "v2"],
  "metadata": {
    "v1": {"algorithm": "LogisticRegression",          "f1_score": 0.39},
    "v2": {"algorithm": "GradientBoostingClassifier",  "f1_score": 0.05}
  },
  "ab_split_v2": 0.5
}
```

---

### `GET /features`

Return the list of expected input features.

```bash
curl http://localhost:5000/features
```

---

## A/B Testing

See [`ab_test_plan.md`](ab_test_plan.md) for the full plan.

**Quick summary:**
- **Control (v1):** LogisticRegression — 50% traffic
- **Treatment (v2):** GradientBoosting — 50% traffic
- **Primary metric:** F1-score (default class)
- **Secondary metric:** Recall (minimize missed defaults)
- **Business metrics:** Expected Loss Reduction, Approval Rate
- **Success criterion:** `ΔF1 ≥ 0.03`, `p-value < 0.05`, no Recall regression
- **Duration:** minimum 4 weeks / 1 000 samples per group

---

## Architecture

See [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) for:
- Monolith vs microservices decision
- RabbitMQ async processing concept
- ELK logging stack
- DVC + MLflow MLOps tools
- ONNX-ML export overview
- uWSGI + NGINX production stack

---

## Docker Hub

```
docker pull YOUR_DOCKERHUB_USERNAME/credit-card-default-predictor:latest
```

Image link: https://hub.docker.com/r/YOUR_DOCKERHUB_USERNAME/credit-card-default-predictor
